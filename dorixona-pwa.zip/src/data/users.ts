import { User, Order, Prescription, Consultation, Notification } from '../types';

export const testUsers: User[] = [
  {
    id: 'admin1',
    phone: '+998901234567',
    name: 'Admin',
    role: 'admin',
    createdAt: '2026-01-01'
  },
  {
    id: 'pharm1',
    phone: '+998901234568',
    name: 'Dr. Aziza Karimova',
    role: 'pharmacist',
    createdAt: '2026-01-01'
  },
  {
    id: 'cust1',
    phone: '+998901234569',
    name: 'Alisher Rahimov',
    role: 'customer',
    address: 'Toshkent, Chilonzor 8-kvartal, 12-uy',
    createdAt: '2026-08-01'
  },
  {
    id: 'courier1',
    phone: '+998901234570',
    name: 'Bekzod Tursunov',
    role: 'courier',
    createdAt: '2026-01-01'
  }
];

export const testOrders: Order[] = [
  {
    id: 'ord1',
    customerId: 'cust1',
    customerName: 'Alisher Rahimov',
    customerPhone: '+998901234569',
    items: [
      { medicine: {
        id: '1', name: 'Paracetamol', nameCyrillic: 'Парацетамол',
        description: '', descriptionCyrillic: '', price: 8500, stock: 150,
        category: 'painkillers', image: '', manufacturer: '', rating: 4.8, reviews: 234, prescription: false
      }, quantity: 2 },
      { medicine: {
        id: '2', name: 'Vitamin C', nameCyrillic: 'Витамин С',
        description: '', descriptionCyrillic: '', price: 15000, stock: 89,
        category: 'vitamins', image: '', manufacturer: '', rating: 4.6, reviews: 189, prescription: false
      }, quantity: 1 }
    ],
    totalAmount: 32000,
    status: 'out_for_delivery',
    paymentMethod: 'cash',
    paymentStatus: 'pending',
    deliveryAddress: 'Toshkent, Chilonzor 8-kvartal, 12-uy',
    courierId: 'courier1',
    courierName: 'Bekzod Tursunov',
    createdAt: '2026-08-07T10:00:00',
    updatedAt: '2026-08-07T12:00:00'
  }
];

export const testPrescriptions: Prescription[] = [
  {
    id: 'pres1',
    customerId: 'cust1',
    customerName: 'Alisher Rahimov',
    image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=400',
    status: 'pending',
    createdAt: '2026-08-07T09:00:00'
  }
];

export const testConsultations: Consultation[] = [
  {
    id: 'cons1',
    customerId: 'cust1',
    customerName: 'Alisher Rahimov',
    status: 'waiting',
    messages: [],
    createdAt: '2026-08-07T11:00:00'
  }
];

export const testNotifications: Notification[] = [
  {
    id: 'notif1',
    userId: 'cust1',
    title: 'Buyurtma holati',
    message: 'Sizning buyurtmangiz yo'lda!',
    read: false,
    type: 'order',
    createdAt: '2026-08-07T12:00:00'
  }
];
