import { useNavigate, useLocation } from 'react-router-dom';
import { Home, Search, ClipboardList, MessageCircle, User } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';

export default function BottomNav() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const { t } = useLanguage();

  if (!user || user.role !== 'customer') return null;

  const navItems = [
    { path: '/', icon: Home, label: t('Bosh sahifa', 'Бош саҳифа') },
    { path: '/catalog', icon: Search, label: t('Katalog', 'Каталог') },
    { path: '/orders', icon: ClipboardList, label: t('Buyurtmalar', 'Буюртмалар') },
    { path: '/chat', icon: MessageCircle, label: t('Maslahat', 'Маслаҳат') },
    { path: '/profile', icon: User, label: t('Profil', 'Профил') },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 safe-bottom">
      <div className="max-w-lg mx-auto flex justify-around items-center h-16">
        {navItems.map(item => {
          const isActive = location.pathname === item.path;
          const Icon = item.icon;
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`flex flex-col items-center gap-0.5 px-3 py-1 rounded-lg transition-colors ${
                isActive ? 'text-primary-500' : 'text-gray-400'
              }`}
            >
              <Icon size={22} strokeWidth={isActive ? 2.5 : 2} />
              <span className="text-[10px] font-medium">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}