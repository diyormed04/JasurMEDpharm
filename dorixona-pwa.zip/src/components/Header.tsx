import { useNavigate } from 'react-router-dom';
import { Bell, ShoppingCart, ArrowLeft, Globe } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { useLanguage } from '../context/LanguageContext';

interface HeaderProps {
  title?: string;
  showBack?: boolean;
  showCart?: boolean;
  showBell?: boolean;
}

export default function Header({ title, showBack = false, showCart = true, showBell = true }: HeaderProps) {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { totalItems } = useCart();
  const { language, toggleLanguage, t } = useLanguage();

  return (
    <header className="sticky top-0 z-50 bg-primary-500 text-white safe-top">
      <div className="max-w-lg mx-auto px-4 h-14 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {showBack && (
            <button onClick={() => navigate(-1)} className="p-1 -ml-1 active:scale-90 transition-transform">
              <ArrowLeft size={24} />
            </button>
          )}
          <h1 className="text-lg font-bold">{title || t('Dorixona', 'Дорихона')}</h1>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={toggleLanguage}
            className="p-2 rounded-lg bg-white/20 active:bg-white/30 transition-colors"
            title={language === 'latin' ? 'Кириллча' : 'Lotincha'}
          >
            <Globe size={18} />
            <span className="text-xs ml-1">{language === 'latin' ? 'UZ' : 'УЗ'}</span>
          </button>
          {showBell && user && (
            <button className="p-2 rounded-lg bg-white/20 active:bg-white/30 transition-colors relative">
              <Bell size={20} />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
          )}
          {showCart && user?.role === 'customer' && (
            <button 
              onClick={() => navigate('/cart')}
              className="p-2 rounded-lg bg-white/20 active:bg-white/30 transition-colors relative"
            >
              <ShoppingCart size={20} />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center font-bold">
                  {totalItems}
                </span>
              )}
            </button>
          )}
        </div>
      </div>
    </header>
  );
}