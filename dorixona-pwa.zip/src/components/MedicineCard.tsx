import { useNavigate } from 'react-router-dom';
import { Heart, Plus } from 'lucide-react';
import { Medicine } from '../types';
import { useCart } from '../context/CartContext';
import { useLanguage } from '../context/LanguageContext';

interface Props {
  medicine: Medicine;
}

export default function MedicineCard({ medicine }: Props) {
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { language, t } = useLanguage();

  const displayName = language === 'latin' ? medicine.name : (medicine.nameCyrillic || medicine.name);

  return (
    <div 
      onClick={() => navigate(`/medicine/${medicine.id}`)}
      className="card active:scale-95 transition-transform cursor-pointer"
    >
      <div className="relative">
        <img 
          src={medicine.image} 
          alt={displayName}
          className="w-full h-40 object-cover"
          loading="lazy"
        />
        {medicine.oldPrice && (
          <span className="absolute top-2 left-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-lg">
            -{Math.round((1 - medicine.price / medicine.oldPrice) * 100)}%
          </span>
        )}
        {medicine.prescription && (
          <span className="absolute top-2 right-2 bg-amber-500 text-white text-xs font-bold px-2 py-1 rounded-lg">
            {t('Retsept', 'Рецепт')}
          </span>
        )}
        <button 
          onClick={(e) => { e.stopPropagation(); }}
          className="absolute bottom-2 right-2 p-2 bg-white rounded-full shadow-md active:scale-90 transition-transform"
        >
          <Heart size={16} className="text-gray-400" />
        </button>
      </div>
      <div className="p-3">
        <h3 className="font-semibold text-gray-800 text-sm line-clamp-1">{displayName}</h3>
        <p className="text-xs text-gray-500 mt-0.5">{medicine.manufacturer}</p>
        <div className="flex items-end justify-between mt-2">
          <div>
            <span className="text-lg font-bold text-primary-600">{medicine.price.toLocaleString()} so'm</span>
            {medicine.oldPrice && (
              <span className="text-xs text-gray-400 line-through ml-1">{medicine.oldPrice.toLocaleString()}</span>
            )}
          </div>
          <button
            onClick={(e) => { 
              e.stopPropagation(); 
              addToCart(medicine);
            }}
            className="p-2 bg-primary-500 text-white rounded-xl active:scale-90 transition-transform shadow-lg shadow-primary-500/30"
          >
            <Plus size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}