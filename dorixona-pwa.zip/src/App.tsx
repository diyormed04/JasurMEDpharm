import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { CartProvider } from './context/CartContext';
import { LanguageProvider } from './context/LanguageContext';
import Login from './pages/Login';
import Home from './pages/Home';
import Catalog from './pages/Catalog';
import MedicineDetail from './pages/MedicineDetail';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import Orders from './pages/Orders';
import OrderTracking from './pages/OrderTracking';
import Prescription from './pages/Prescription';
import ChatPage from './pages/ChatPage';
import Profile from './pages/Profile';
import AdminDashboard from './pages/AdminDashboard';
import AdminMedicines from './pages/AdminMedicines';
import AdminOrders from './pages/AdminOrders';
import AdminUsers from './pages/AdminUsers';
import PharmacistDashboard from './pages/PharmacistDashboard';
import PharmacistQueue from './pages/PharmacistQueue';
import CourierDashboard from './pages/CourierDashboard';
import CourierOrders from './pages/CourierOrders';
import MapPage from './pages/MapPage';

function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/" element={<Home />} />
            <Route path="/catalog" element={<Catalog />} />
            <Route path="/medicine/:id" element={<MedicineDetail />} />
            <Route path="/cart" element={<Cart />} />
            <Route path="/checkout" element={<Checkout />} />
            <Route path="/orders" element={<Orders />} />
            <Route path="/tracking/:id" element={<OrderTracking />} />
            <Route path="/prescription" element={<Prescription />} />
            <Route path="/chat/:id?" element={<ChatPage />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/admin/medicines" element={<AdminMedicines />} />
            <Route path="/admin/orders" element={<AdminOrders />} />
            <Route path="/admin/users" element={<AdminUsers />} />
            <Route path="/pharmacist" element={<PharmacistDashboard />} />
            <Route path="/pharmacist/queue" element={<PharmacistQueue />} />
            <Route path="/courier" element={<CourierDashboard />} />
            <Route path="/courier/orders" element={<CourierOrders />} />
            <Route path="/map" element={<MapPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </LanguageProvider>
  );
}

export default App;