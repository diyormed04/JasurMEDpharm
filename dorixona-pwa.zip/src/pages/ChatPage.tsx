import { useState, useRef, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Send, Phone, Video, MoreVertical, ChevronLeft } from 'lucide-react';
import { ChatMessage } from '../types';
import Header from '../components/Header';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';

export default function ChatPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const { t } = useLanguage();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      senderId: 'pharm1',
      senderName: 'Dr. Aziza',
      senderRole: 'pharmacist',
      text: 'Assalomu alaykum! Sizga qanday yordam bera olaman?',
      timestamp: '10:00'
    }
  ]);
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = () => {
    if (!inputText.trim() || !user) return;

    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      senderId: user.id,
      senderName: user.name,
      senderRole: user.role,
      text: inputText,
      timestamp: new Date().toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, newMessage]);
    setInputText('');

    // Auto-reply from pharmacist
    if (user.role === 'customer') {
      setTimeout(() => {
        const reply: ChatMessage = {
          id: (Date.now() + 1).toString(),
          senderId: 'pharm1',
          senderName: 'Dr. Aziza',
          senderRole: 'pharmacist',
          text: 'Tushundim, sizga qaysi dorini tavsiya qilishim mumkin?',
          timestamp: new Date().toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' })
        };
        setMessages(prev => [...prev, reply]);
      }, 2000);
    }
  };

  return (
    <div className="page-container flex flex-col h-screen">
      <Header title={t('Maslahat', 'Маслаҳат')} showBack />

      {/* Chat Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-3">
        <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600">
          <span className="text-lg">👩‍⚕️</span>
        </div>
        <div className="flex-1">
          <div className="font-semibold text-gray-800">Dr. Aziza Karimova</div>
          <div className="text-xs text-emerald-600 flex items-center gap-1">
            <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></div>
            {t('Onlayn', 'Онлайн')}
          </div>
        </div>
        <button className="p-2 text-gray-400">
          <Phone size={20} />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        {messages.map(msg => {
          const isMe = msg.senderId === user?.id;
          return (
            <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] px-4 py-2 rounded-2xl ${
                isMe 
                  ? 'bg-primary-500 text-white rounded-br-md' 
                  : 'bg-white text-gray-800 rounded-bl-md shadow-sm'
              }`}>
                <p className="text-sm">{msg.text}</p>
                <span className={`text-[10px] mt-1 block ${isMe ? 'text-primary-100' : 'text-gray-400'}`}>
                  {msg.timestamp}
                </span>
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="bg-white border-t border-gray-200 p-3 safe-bottom">
        <div className="flex items-center gap-2 max-w-lg mx-auto">
          <input
            type="text"
            value={inputText}
            onChange={e => setInputText(e.target.value)}
            onKeyPress={e => e.key === 'Enter' && handleSend()}
            placeholder={t('Xabar yozing...', 'Хабар ёзинг...')}
            className="flex-1 input-field py-2"
          />
          <button
            onClick={handleSend}
            disabled={!inputText.trim()}
            className="p-3 bg-primary-500 text-white rounded-xl active:scale-90 transition-transform disabled:opacity-50"
          >
            <Send size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}