import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, SlidersHorizontal, X, ChevronDown } from 'lucide-react';
import { medicines, categories } from '../data/medicines';
import Header from '../components/Header';
import BottomNav from '../components/BottomNav';
import MedicineCard from '../components/MedicineCard';
import { useLanguage } from '../context/LanguageContext';

export default function Catalog() {
  const navigate = useNavigate();
  const { language, t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showFilters, setShowFilters] = useState(false);
  const [sortBy, setSortBy] = useState<'price-asc' | 'price-desc' | 'popular'>('popular');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 100000]);

  const filteredMedicines = useMemo(() => {
    let result = [...medicines];

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(m => 
        m.name.toLowerCase().includes(query) ||
        m.nameCyrillic?.toLowerCase().includes(query) ||
        m.description.toLowerCase().includes(query) ||
        m.symptoms?.some(s => s.toLowerCase().includes(query))
      );
    }

    if (selectedCategory !== 'all') {
      result = result.filter(m => m.category === selectedCategory);
    }

    result = result.filter(m => m.price >= priceRange[0] && m.price <= priceRange[1]);

    switch (sortBy) {
      case 'price-asc':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        result.sort((a, b) => b.price - a.price);
        break;
      default:
        result.sort((a, b) => b.rating - a.rating);
    }

    return result;
  }, [searchQuery, selectedCategory, sortBy, priceRange]);

  return (
    <div className="page-container">
      <Header title={t('Katalog', 'Каталог')} showBack />

      {/* Search & Filter */}
      <div className="px-4 py-3 sticky top-14 bg-gray-50 z-40 border-b border-gray-200">
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder={t('Dori nomi yoki simptom...', 'Дори номи ёки симптом...')}
              className="input-field pl-10"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2"
              >
                <X size={16} className="text-gray-400" />
              </button>
            )}
          </div>
          <button 
            onClick={() => setShowFilters(!showFilters)}
            className={`p-3 rounded-xl border transition-colors ${
              showFilters ? 'bg-primary-500 text-white border-primary-500' : 'bg-white text-gray-600 border-gray-200'
            }`}
          >
            <SlidersHorizontal size={20} />
          </button>
        </div>

        {/* Filters */}
        {showFilters && (
          <div className="mt-3 p-3 bg-white rounded-xl border border-gray-200 animate-slide-up">
            <div className="mb-3">
              <label className="text-sm font-medium text-gray-700 mb-1 block">{t('Saralash', 'Саралаш')}</label>
              <div className="flex gap-2">
                {[
                  { id: 'popular' as const, label: t('Mashhur', 'Машҳур') },
                  { id: 'price-asc' as const, label: t('Arzon → Qimmat', 'Арзон → Қиммат') },
                  { id: 'price-desc' as const, label: t('Qimmat → Arzon', 'Қиммат → Арзон') },
                ].map(opt => (
                  <button
                    key={opt.id}
                    onClick={() => setSortBy(opt.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      sortBy === opt.id ? 'bg-primary-500 text-white' : 'bg-gray-100 text-gray-600'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">{t('Narx oralig\'i', 'Нарх оралиғи')}</label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  value={priceRange[0]}
                  onChange={e => setPriceRange([Number(e.target.value), priceRange[1]])}
                  className="input-field text-sm py-2"
                  placeholder="Min"
                />
                <span className="text-gray-400">-</span>
                <input
                  type="number"
                  value={priceRange[1]}
                  onChange={e => setPriceRange([priceRange[0], Number(e.target.value)])}
                  className="input-field text-sm py-2"
                  placeholder="Max"
                />
              </div>
            </div>
          </div>
        )}

        {/* Categories */}
        <div className="flex gap-2 mt-3 overflow-x-auto no-scrollbar">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                selectedCategory === cat.id 
                  ? 'bg-primary-500 text-white' 
                  : 'bg-white text-gray-600 border border-gray-200'
              }`}
            >
              {language === 'latin' ? cat.name : cat.nameCyrillic}
            </button>
          ))}
        </div>
      </div>

      {/* Results */}
      <div className="px-4 pt-4 pb-24">
        <p className="text-sm text-gray-500 mb-3">
          {filteredMedicines.length} {t('ta dori topildi', 'та дори топилди')}
        </p>
        <div className="grid grid-cols-2 gap-3">
          {filteredMedicines.map(med => (
            <MedicineCard key={med.id} medicine={med} />
          ))}
        </div>
        {filteredMedicines.length === 0 && (
          <div className="text-center py-12">
            <span className="text-6xl mb-4 block">🔍</span>
            <p className="text-gray-500">{t('Hech narsa topilmadi', 'Ҳеч нарса топилмади')}</p>
            <button 
              onClick={() => { setSearchQuery(''); setSelectedCategory('all'); }}
              className="mt-2 text-primary-500 font-medium"
            >
              {t('Filterni tozalash', 'Филтерни тозалаш')}
            </button>
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}