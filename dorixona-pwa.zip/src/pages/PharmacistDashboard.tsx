import { useNavigate } from 'react-router-dom';
import { Stethoscope, FileText, MessageCircle, Clock, CheckCircle, Users } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import Header from '../components/Header';

export default function PharmacistDashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { t } = useLanguage();

  if (!user || user.role !== 'pharmacist') {
    return (
      <div className="page-container flex items-center justify-center">
        <p className="text-gray-500">{t('Ruxsat yo\'q', 'Рухсат йўқ')}</p>
      </div>
    );
  }

  const [isOnline, setIsOnline] = useState(true);

  const stats = [
    { icon: FileText, label: t('Retseptlar', 'Рецептлар'), value: '3', color: 'bg-amber-500' },
    { icon: Users, label: t('Navbat', 'Навбат'), value: '2', color: 'bg-blue-500' },
    { icon: CheckCircle, label: t('Tasdiqlangan', 'Тасдиқланган'), value: '15', color: 'bg-emerald-500' },
  ];

  return (
    <div className="page-container">
      <Header title={t('Farmatsevt Paneli', 'Фарматсевт Панели')} showBack={false} showCart={false} />

      <div className="px-4 pt-4 space-y-4 pb-24">
        {/* Online Toggle */}
        <div className="card p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${isOnline ? 'bg-emerald-100 text-emerald-600' : 'bg-gray-100 text-gray-400'}`}>
              <Stethoscope size={24} />
            </div>
            <div>
              <h2 className="font-bold text-gray-800">{user.name}</h2>
              <p className="text-sm text-gray-500">{t('Farmatsevt', 'Фарматсевт')}</p>
            </div>
          </div>
          <button
            onClick={() => setIsOnline(!isOnline)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              isOnline ? 'bg-emerald-500 text-white' : 'bg-gray-200 text-gray-600'
            }`}
          >
            {isOnline ? t('Onlayn', 'Онлайн') : t('Oflayn', 'Офлайн')}
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <div key={idx} className="card p-3 text-center">
                <div className={`w-8 h-8 ${stat.color} rounded-lg flex items-center justify-center text-white mx-auto mb-2`}>
                  <Icon size={16} />
                </div>
                <div className="text-xl font-bold text-gray-800">{stat.value}</div>
                <div className="text-[10px] text-gray-500">{stat.label}</div>
              </div>
            );
          })}
        </div>

        {/* Quick Actions */}
        <div className="space-y-2">
          <button
            onClick={() => navigate('/pharmacist/queue')}
            className="w-full card p-4 flex items-center gap-3 active:scale-[0.98] transition-transform"
          >
            <div className="w-12 h-12 rounded-xl flex items-center justify-center text-blue-600 bg-blue-50">
              <MessageCircle size={24} />
            </div>
            <div className="text-left flex-1">
              <div className="font-medium text-gray-700">{t('Maslahat navbati', 'Маслаҳат навбати')}</div>
              <div className="text-sm text-gray-500">{t('2 ta mijoz kutmoqda', '2 та мижоз кутмоқда')}</div>
            </div>
          </button>

          <button
            onClick={() => navigate('/pharmacist/queue')}
            className="w-full card p-4 flex items-center gap-3 active:scale-[0.98] transition-transform"
          >
            <div className="w-12 h-12 rounded-xl flex items-center justify-center text-amber-600 bg-amber-50">
              <FileText size={24} />
            </div>
            <div className="text-left flex-1">
              <div className="font-medium text-gray-700">{t('Retseptlarni ko\'rib chiqish', 'Рецептларни кўриб чиқиш')}</div>
              <div className="text-sm text-gray-500">{t('3 ta yangi retsept', '3 та янги рецепт')}</div>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}