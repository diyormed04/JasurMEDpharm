import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Minus, Plus, ShoppingCart, MessageCircle, Star, Check, AlertCircle } from 'lucide-react';
import { medicines } from '../data/medicines';
import Header from '../components/Header';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';

export default function MedicineDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart, items } = useCart();
  const { user } = useAuth();
  const { language, t } = useLanguage();
  const [quantity, setQuantity] = useState(1);

  const medicine = medicines.find(m => m.id === id);
  const cartItem = items.find(item => item.medicine.id === id);

  if (!medicine) {
    return (
      <div className="page-container flex items-center justify-center">
        <p className="text-gray-500">{t('Dori topilmadi', 'Дори топилмади')}</p>
      </div>
    );
  }

  const displayName = language === 'latin' ? medicine.name : (medicine.nameCyrillic || medicine.name);
  const displayDesc = language === 'latin' ? medicine.description : (medicine.descriptionCyrillic || medicine.description);

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart(medicine);
    }
  };

  return (
    <div className="page-container">
      <Header showBack />

      {/* Image */}
      <div className="relative">
        <img 
          src={medicine.image} 
          alt={displayName}
          className="w-full h-64 object-cover"
        />
        {medicine.oldPrice && (
          <span className="absolute top-4 left-4 bg-red-500 text-white font-bold px-3 py-1 rounded-xl">
            -{Math.round((1 - medicine.price / medicine.oldPrice) * 100)}%
          </span>
        )}
      </div>

      <div className="px-4 -mt-6 relative z-10">
        <div className="card p-4">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-xl font-bold text-gray-800">{displayName}</h1>
              <p className="text-sm text-gray-500 mt-1">{medicine.manufacturer}</p>
            </div>
            {medicine.prescription && (
              <span className="bg-amber-100 text-amber-700 text-xs font-bold px-2 py-1 rounded-lg flex items-center gap-1">
                <AlertCircle size={12} />
                {t('Retsept', 'Рецепт')}
              </span>
            )}
          </div>

          {/* Rating */}
          <div className="flex items-center gap-2 mt-3">
            <div className="flex items-center gap-1">
              <Star size={16} className="text-yellow-400 fill-yellow-400" />
              <span className="font-semibold">{medicine.rating}</span>
            </div>
            <span className="text-gray-400">•</span>
            <span className="text-sm text-gray-500">{medicine.reviews} {t('sharhlarni', 'шарҳларни')}</span>
          </div>

          {/* Price */}
          <div className="mt-4 flex items-end gap-3">
            <span className="text-3xl font-bold text-primary-600">{medicine.price.toLocaleString()} so'm</span>
            {medicine.oldPrice && (
              <span className="text-lg text-gray-400 line-through">{medicine.oldPrice.toLocaleString()} so'm</span>
            )}
          </div>

          {/* Stock */}
          <div className="mt-3 flex items-center gap-2">
            <Check size={16} className="text-emerald-500" />
            <span className="text-sm text-emerald-600 font-medium">
              {t('Omborda', 'Омборда')}: {medicine.stock} {t('ta', 'та')}
            </span>
          </div>
        </div>

        {/* Description */}
        <div className="card p-4 mt-4">
          <h2 className="font-bold text-gray-800 mb-2">{t('Tavsif', 'Тавсиф')}</h2>
          <p className="text-gray-600 text-sm leading-relaxed">{displayDesc}</p>
          {medicine.dosage && (
            <div className="mt-3 p-3 bg-primary-50 rounded-xl">
              <span className="text-sm font-medium text-primary-700">{t('Dozasi', 'Дозаси')}: {medicine.dosage}</span>
            </div>
          )}
        </div>

        {/* Symptoms */}
        {medicine.symptoms && medicine.symptoms.length > 0 && (
          <div className="card p-4 mt-4">
            <h2 className="font-bold text-gray-800 mb-2">{t('Simptomlar', 'Симптомлар')}</h2>
            <div className="flex flex-wrap gap-2">
              {medicine.symptoms.map(symptom => (
                <span key={symptom} className="px-3 py-1 bg-gray-100 text-gray-600 text-sm rounded-full">
                  {symptom}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Actions */}
        {user?.role === 'customer' && (
          <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 safe-bottom z-50">
            <div className="max-w-lg mx-auto flex items-center gap-4">
              {/* Quantity */}
              <div className="flex items-center gap-3 bg-gray-100 rounded-xl px-3 py-2">
                <button 
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="p-1 active:scale-90 transition-transform"
                >
                  <Minus size={18} className="text-gray-600" />
                </button>
                <span className="font-bold w-6 text-center">{quantity}</span>
                <button 
                  onClick={() => setQuantity(Math.min(medicine.stock, quantity + 1))}
                  className="p-1 active:scale-90 transition-transform"
                >
                  <Plus size={18} className="text-gray-600" />
                </button>
              </div>

              {/* Add to Cart */}
              <button 
                onClick={handleAddToCart}
                className="flex-1 btn-primary flex items-center justify-center gap-2"
              >
                <ShoppingCart size={20} />
                <span>
                  {cartItem 
                    ? t('Savatda', 'Саватда') + ` (${cartItem.quantity})` 
                    : t('Savatga qo\'shish', 'Саватга қўшиш')
                  }
                </span>
              </button>
            </div>
          </div>
        )}

        {/* Pharmacist Advice Button */}
        <button
          onClick={() => navigate('/chat')}
          className="w-full mt-4 mb-24 btn-secondary flex items-center justify-center gap-2"
        >
          <MessageCircle size={20} />
          <span>{t('Farmatsevtdan maslahat', 'Фарматсевтдан маслаҳат')}</span>
        </button>
      </div>
    </div>
  );
}