import { useNavigate } from 'react-router-dom';
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight } from 'lucide-react';
import { useCart } from '../context/CartContext';
import Header from '../components/Header';
import BottomNav from '../components/BottomNav';
import { useLanguage } from '../context/LanguageContext';

export default function Cart() {
  const navigate = useNavigate();
  const { items, updateQuantity, removeFromCart, totalPrice } = useCart();
  const { language, t } = useLanguage();

  return (
    <div className="page-container">
      <Header title={t('Savat', 'Сават')} showBack />

      {items.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-[60vh]">
          <span className="text-6xl mb-4">🛒</span>
          <h2 className="text-xl font-bold text-gray-800">{t('Savat bo\'sh', 'Сават бўш')}</h2>
          <p className="text-gray-500 mt-2 text-center px-8">{t('Dorilarni katalogdan tanlang', 'Дориларни каталогдан танланг')}</p>
          <button 
            onClick={() => navigate('/catalog')}
            className="btn-primary mt-6"
          >
            {t('Katalogga o\'tish', 'Каталогга ўтиш')}
          </button>
        </div>
      ) : (
        <>
          <div className="px-4 pt-4 space-y-3">
            {items.map(item => (
              <div key={item.medicine.id} className="card p-3 flex gap-3">
                <img 
                  src={item.medicine.image} 
                  alt={language === 'latin' ? item.medicine.name : (item.medicine.nameCyrillic || item.medicine.name)}
                  className="w-20 h-20 object-cover rounded-xl"
                />
                <div className="flex-1">
                  <h3 className="font-semibold text-sm text-gray-800">
                    {language === 'latin' ? item.medicine.name : (item.medicine.nameCyrillic || item.medicine.name)}
                  </h3>
                  <p className="text-xs text-gray-500">{item.medicine.manufacturer}</p>
                  <div className="flex items-center justify-between mt-2">
                    <span className="font-bold text-primary-600">
                      {(item.medicine.price * item.quantity).toLocaleString()} so'm
                    </span>
                    <div className="flex items-center gap-2">
                      <button 
                        onClick={() => updateQuantity(item.medicine.id, item.quantity - 1)}
                        className="p-1 bg-gray-100 rounded-lg active:scale-90 transition-transform"
                      >
                        <Minus size={14} />
                      </button>
                      <span className="font-medium w-6 text-center">{item.quantity}</span>
                      <button 
                        onClick={() => updateQuantity(item.medicine.id, item.quantity + 1)}
                        className="p-1 bg-gray-100 rounded-lg active:scale-90 transition-transform"
                      >
                        <Plus size={14} />
                      </button>
                      <button 
                        onClick={() => removeFromCart(item.medicine.id)}
                        className="p-1 text-red-500 active:scale-90 transition-transform ml-2"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Summary */}
          <div className="fixed bottom-16 left-0 right-0 bg-white border-t border-gray-200 p-4">
            <div className="max-w-lg mx-auto">
              <div className="flex justify-between items-center mb-3">
                <span className="text-gray-600">{t('Jami', 'Жами')}:</span>
                <span className="text-2xl font-bold text-primary-600">{totalPrice.toLocaleString()} so'm</span>
              </div>
              <button 
                onClick={() => navigate('/checkout')}
                className="btn-primary w-full flex items-center justify-center gap-2"
              >
                <span>{t('Buyurtma berish', 'Буюртма бериш')}</span>
                <ArrowRight size={20} />
              </button>
            </div>
          </div>
        </>
      )}

      <BottomNav />
    </div>
  );
}