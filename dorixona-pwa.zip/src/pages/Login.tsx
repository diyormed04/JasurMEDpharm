import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Phone, Lock, Stethoscope, Truck, Shield, User } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';

export default function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const { t } = useLanguage();
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [role, setRole] = useState<'customer' | 'pharmacist' | 'courier' | 'admin'>('customer');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanPhone = phone.replace(/\D/g, '');
    if (cleanPhone.length < 9) {
      setError(t('Telefon raqam noto\'g\'ri', 'Телефон рақам нотўғри'));
      return;
    }

    const fullPhone = cleanPhone.startsWith('998') ? '+' + cleanPhone : '+998' + cleanPhone;

    if (login(fullPhone, password)) {
      navigate('/');
    } else {
      setError(t('Telefon yoki parol noto\'g\'ri', 'Телефон ёки парол нотўғри'));
    }
  };

  const roles = [
    { id: 'customer' as const, icon: User, label: t('Mijoz', 'Мижоз'), color: 'bg-emerald-500' },
    { id: 'pharmacist' as const, icon: Stethoscope, label: t('Farmatsevt', 'Фарматсевт'), color: 'bg-blue-500' },
    { id: 'courier' as const, icon: Truck, label: t('Kuriyer', 'Курйер'), color: 'bg-amber-500' },
    { id: 'admin' as const, icon: Shield, label: t('Admin', 'Админ'), color: 'bg-red-500' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center p-4">
      <div className="w-full max-w-sm animate-slide-up">
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-white rounded-3xl mx-auto flex items-center justify-center shadow-xl mb-4">
            <span className="text-4xl">🏥</span>
          </div>
          <h1 className="text-3xl font-bold text-white">{t('Dorixona', 'Дорихона')}</h1>
          <p className="text-primary-100 mt-2">{t('Onlayn dorixona xizmati', 'Онлайн дорихона хизмати')}</p>
        </div>

        <div className="bg-white rounded-3xl p-6 shadow-2xl">
          <div className="grid grid-cols-4 gap-2 mb-6">
            {roles.map(r => {
              const Icon = r.icon;
              return (
                <button
                  key={r.id}
                  onClick={() => setRole(r.id)}
                  className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-all ${
                    role === r.id ? `${r.color} text-white shadow-lg` : 'bg-gray-100 text-gray-500'
                  }`}
                >
                  <Icon size={20} />
                  <span className="text-[10px] font-medium">{r.label}</span>
                </button>
              );
            })}
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">{t('Telefon raqam', 'Телефон рақам')}</label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <input
                  type="tel"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  placeholder="90 123 45 67"
                  className="input-field pl-10"
                  required
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">{t('Parol (4 ta raqam)', 'Парол (4 та рақам)')}</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <input
                  type="password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="****"
                  maxLength={4}
                  className="input-field pl-10"
                  required
                />
              </div>
            </div>

            {error && (
              <p className="text-red-500 text-sm text-center bg-red-50 p-2 rounded-lg">{error}</p>
            )}

            <button type="submit" className="btn-primary w-full">
              {t('Kirish', 'Кириш')}
            </button>
          </form>

          <div className="mt-4 p-3 bg-gray-50 rounded-xl text-xs text-gray-500">
            <p className="font-semibold mb-1">{t('Test akkauntlar:', 'Тест аккаунтлар:')}</p>
            <p>Mijoz: +998901234569 / 4569</p>
            <p>Farmatsevt: +998901234568 / 4568</p>
            <p>Kuriyer: +998901234570 / 4570</p>
            <p>Admin: +998901234567 / 4567</p>
          </div>
        </div>
      </div>
    </div>
  );
}