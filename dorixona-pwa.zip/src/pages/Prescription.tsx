import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Camera, Upload, FileText, Check, Clock, X, Send } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import Header from '../components/Header';
import BottomNav from '../components/BottomNav';

export default function Prescription() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { t } = useLanguage();
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setUploadedImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async () => {
    if (!uploadedImage) return;
    setIsSubmitting(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsSubmitting(false);
    setSubmitted(true);
  };

  return (
    <div className="page-container">
      <Header title={t('Retsept', 'Рецепт')} showBack />

      <div className="px-4 pt-4 space-y-4 pb-24">
        {!submitted ? (
          <>
            <div className="card p-4">
              <h2 className="font-bold text-gray-800 mb-2">{t('Retsept yuborish', 'Рецепт юбориш')}</h2>
              <p className="text-sm text-gray-500">{t('Doktor yozgan retseptni suratga oling yoki yuklang', 'Доктор ёзган рецептни суратга олинг ёки юкланг')}</p>
            </div>

            {/* Upload Area */}
            <div className="card p-4">
              {!uploadedImage ? (
                <div className="border-2 border-dashed border-gray-300 rounded-2xl p-8 text-center">
                  <div className="flex justify-center gap-4 mb-4">
                    <button 
                      onClick={() => fileInputRef.current?.click()}
                      className="w-16 h-16 bg-primary-100 rounded-2xl flex items-center justify-center text-primary-600 active:scale-90 transition-transform"
                    >
                      <Camera size={28} />
                    </button>
                    <button 
                      onClick={() => fileInputRef.current?.click()}
                      className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600 active:scale-90 transition-transform"
                    >
                      <Upload size={28} />
                    </button>
                  </div>
                  <p className="text-sm text-gray-500">{t('Rasm tanlash uchun bosing', 'Расм танлаш учун босинг')}</p>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </div>
              ) : (
                <div className="relative">
                  <img src={uploadedImage} alt="Prescription" className="w-full rounded-xl" />
                  <button
                    onClick={() => setUploadedImage(null)}
                    className="absolute top-2 right-2 p-2 bg-red-500 text-white rounded-full active:scale-90 transition-transform"
                  >
                    <X size={16} />
                  </button>
                </div>
              )}
            </div>

            {uploadedImage && (
              <button
                onClick={handleSubmit}
                disabled={isSubmitting}
                className="btn-primary w-full flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <span className="animate-spin">⏳</span>
                ) : (
                  <>
                    <Send size={20} />
                    <span>{t('Yuborish', 'Юбориш')}</span>
                  </>
                )}
              </button>
            )}
          </>
        ) : (
          <div className="text-center py-12">
            <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600 mx-auto mb-4">
              <Check size={40} />
            </div>
            <h2 className="text-xl font-bold text-gray-800 mb-2">{t('Retsept yuborildi!', 'Рецепт юборилди!')}</h2>
            <p className="text-gray-500">{t('Farmatsevt ko\'rib chiqqach, sizga xabar beramiz', 'Фарматсевт кўриб чиққач, сизга хабар берамиз')}</p>
            <button 
              onClick={() => navigate('/orders')}
              className="btn-primary mt-6"
            >
              {t('Buyurtmalarga o\'tish', 'Буюртмалarga ўтиш')}
            </button>
          </div>
        )}

        {/* Previous Prescriptions */}
        <div className="card p-4">
          <h2 className="font-bold text-gray-800 mb-3">{t('Avvalgi retseptlar', 'Аввалги рецептлар')}</h2>
          <div className="space-y-3">
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
              <FileText size={20} className="text-gray-400" />
              <div className="flex-1">
                <div className="text-sm font-medium">Retsept #001</div>
                <div className="text-xs text-gray-500">05.08.2026</div>
              </div>
              <span className="status-badge bg-emerald-100 text-emerald-700 flex items-center gap-1">
                <Check size={12} /> {t('Tasdiqlandi', 'Тасдиқланди')}
              </span>
            </div>
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}