import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Truck, Package, MapPin, DollarSign, Clock, CheckCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import Header from '../components/Header';

export default function CourierDashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { t } = useLanguage();
  const [isOnline, setIsOnline] = useState(true);

  if (!user || user.role !== 'courier') {
    return (
      <div className="page-container flex items-center justify-center">
        <p className="text-gray-500">{t('Ruxsat yo\'q', 'Рухсат йўқ')}</p>
      </div>
    );
  }

  const stats = [
    { icon: Package, label: t('Bugun', 'Бугун'), value: '5', color: 'bg-blue-500' },
    { icon: CheckCircle, label: t('Yetkazildi', 'Етказилди'), value: '3', color: 'bg-emerald-500' },
    { icon: DollarSign, label: t('Daromad', 'Даромад'), value: '45K', color: 'bg-amber-500' },
  ];

  return (
    <div className="page-container">
      <Header title={t('Kuriyer Paneli', 'Курйер Панели')} showBack={false} showCart={false} />

      <div className="px-4 pt-4 space-y-4 pb-24">
        {/* Online Toggle */}
        <div className="card p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${isOnline ? 'bg-emerald-100 text-emerald-600' : 'bg-gray-100 text-gray-400'}`}>
              <Truck size={24} />
            </div>
            <div>
              <h2 className="font-bold text-gray-800">{user.name}</h2>
              <p className="text-sm text-gray-500">{t('Kuriyer', 'Курйер')}</p>
            </div>
          </div>
          <button
            onClick={() => setIsOnline(!isOnline)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              isOnline ? 'bg-emerald-500 text-white' : 'bg-gray-200 text-gray-600'
            }`}
          >
            {isOnline ? t('Onlayn', 'Онлайн') : t('Oflayn', 'Офлайн')}
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <div key={idx} className="card p-3 text-center">
                <div className={`w-8 h-8 ${stat.color} rounded-lg flex items-center justify-center text-white mx-auto mb-2`}>
                  <Icon size={16} />
                </div>
                <div className="text-xl font-bold text-gray-800">{stat.value}</div>
                <div className="text-[10px] text-gray-500">{stat.label}</div>
              </div>
            );
          })}
        </div>

        {/* Quick Actions */}
        <div className="space-y-2">
          <button
            onClick={() => navigate('/courier/orders')}
            className="w-full card p-4 flex items-center gap-3 active:scale-[0.98] transition-transform"
          >
            <div className="w-12 h-12 rounded-xl flex items-center justify-center text-blue-600 bg-blue-50">
              <Package size={24} />
            </div>
            <div className="text-left flex-1">
              <div className="font-medium text-gray-700">{t('Mening buyurtmalarim', 'Менинг буюртмаларим')}</div>
              <div className="text-sm text-gray-500">{t('2 ta yetkazish kutilmoqda', '2 та етказиш кутилмоқда')}</div>
            </div>
          </button>

          <button
            onClick={() => navigate('/map')}
            className="w-full card p-4 flex items-center gap-3 active:scale-[0.98] transition-transform"
          >
            <div className="w-12 h-12 rounded-xl flex items-center justify-center text-emerald-600 bg-emerald-50">
              <MapPin size={24} />
            </div>
            <div className="text-left flex-1">
              <div className="font-medium text-gray-700">{t('Xarita', 'Харита')}</div>
              <div className="text-sm text-gray-500">{t('Barcha manzillarni ko\'rish', 'Барча манзилларни кўриш')}</div>
            </div>
          </button>
        </div>

        {/* Today's Route */}
        <div className="card p-4">
          <h2 className="font-bold text-gray-800 mb-3">{t('Bugungi marshrut', 'Бугунги маршрут')}</h2>
          <div className="space-y-3">
            {[
              { address: 'Chilonzor 8-kv, 12-uy', status: 'delivered', time: '09:30' },
              { address: 'Yunusobod 5-kv, 45-uy', status: 'delivering', time: '10:15' },
              { address: 'Mirzo-Ulug'bek 3-kv, 8-uy', status: 'pending', time: '11:00' },
            ].map((route, idx) => (
              <div key={idx} className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold ${
                  route.status === 'delivered' ? 'bg-emerald-500' : 
                  route.status === 'delivering' ? 'bg-blue-500' : 'bg-gray-300'
                }`}>
                  {idx + 1}
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium text-gray-700">{route.address}</div>
                  <div className="text-xs text-gray-500">{route.time}</div>
                </div>
                {route.status === 'delivered' && <CheckCircle size={16} className="text-emerald-500" />}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}