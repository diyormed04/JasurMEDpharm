import { useParams } from 'react-router-dom';
import { Clock, Package, Truck, CheckCircle, MapPin, Phone, MessageCircle } from 'lucide-react';
import { Order } from '../types';
import Header from '../components/Header';
import { useLanguage } from '../context/LanguageContext';
import { useState, useEffect } from 'react';

const statusSteps = [
  { status: 'pending', label: 'Buyurtma qabul qilindi', icon: Clock },
  { status: 'processing', label: 'Tayyorlanmoqda', icon: Package },
  { status: 'ready', label: 'Tayyor', icon: CheckCircle },
  { status: 'out_for_delivery', label: 'Kuriyer yo\'lda', icon: Truck },
  { status: 'delivered', label: 'Yetkazildi', icon: CheckCircle },
];

export default function OrderTracking() {
  const { id } = useParams();
  const { t } = useLanguage();
  const [order, setOrder] = useState<Order | null>(null);

  useEffect(() => {
    const orders = JSON.parse(localStorage.getItem('dorixona_orders') || '[]');
    setOrder(orders.find((o: Order) => o.id === id));
  }, [id]);

  if (!order) {
    return (
      <div className="page-container flex items-center justify-center">
        <p className="text-gray-500">{t('Buyurtma topilmadi', 'Буюртма топилмади')}</p>
      </div>
    );
  }

  const currentStepIndex = statusSteps.findIndex(s => s.status === order.status);

  return (
    <div className="page-container">
      <Header title={t('Buyurtma kuzatuv', 'Буюртма кузатув')} showBack />

      <div className="px-4 pt-4 space-y-4 pb-24">
        {/* Order Info */}
        <div className="card p-4">
          <div className="flex justify-between items-start mb-3">
            <div>
              <span className="text-xs text-gray-500">#{order.id.slice(-6)}</span>
              <h2 className="font-bold text-gray-800">{order.totalAmount.toLocaleString()} so'm</h2>
            </div>
            <span className={`status-badge ${
              order.status === 'delivered' ? 'bg-emerald-100 text-emerald-700' :
              order.status === 'out_for_delivery' ? 'bg-blue-100 text-blue-700' :
              'bg-amber-100 text-amber-700'
            }`}>
              {order.status === 'pending' && t('Kutilmoqda', 'Кутилмоқда')}
              {order.status === 'processing' && t('Tayyorlanmoqda', 'Тайёрланмоқда')}
              {order.status === 'ready' && t('Tayyor', 'Тайёр')}
              {order.status === 'out_for_delivery' && t('Yo\'lda', 'Йўлда')}
              {order.status === 'delivered' && t('Yetkazildi', 'Етказилди')}
            </span>
          </div>

          {order.courierName && (
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
              <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600">
                <Truck size={20} />
              </div>
              <div className="flex-1">
                <div className="font-medium text-sm">{order.courierName}</div>
                <div className="text-xs text-gray-500">{t('Kuriyer', 'Курйер')}</div>
              </div>
              <button className="p-2 bg-primary-500 text-white rounded-lg">
                <Phone size={16} />
              </button>
            </div>
          )}
        </div>

        {/* Tracking Steps */}
        <div className="card p-4">
          <h3 className="font-bold text-gray-800 mb-4">{t('Buyurtma holati', 'Буюртма холати')}</h3>
          <div className="space-y-0">
            {statusSteps.map((step, idx) => {
              const Icon = step.icon;
              const isCompleted = idx <= currentStepIndex;
              const isCurrent = idx === currentStepIndex;

              return (
                <div key={step.status} className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      isCompleted ? 'bg-primary-500 text-white' : 'bg-gray-200 text-gray-400'
                    } ${isCurrent ? 'ring-4 ring-primary-500/20' : ''}`}>
                      <Icon size={18} />
                    </div>
                    {idx < statusSteps.length - 1 && (
                      <div className={`w-0.5 h-8 ${isCompleted ? 'bg-primary-500' : 'bg-gray-200'}`}></div>
                    )}
                  </div>
                  <div className="pb-6">
                    <div className={`font-medium ${isCompleted ? 'text-gray-800' : 'text-gray-400'}`}>
                      {step.label}
                    </div>
                    {isCurrent && (
                      <div className="text-sm text-primary-600 mt-0.5">
                        {t('Joriy holat', 'Жорий холат')}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Delivery Address */}
        <div className="card p-4">
          <div className="flex items-center gap-2 mb-2">
            <MapPin size={18} className="text-primary-500" />
            <h3 className="font-bold text-gray-800">{t('Yetkazish manzili', 'Етказиш манзили')}</h3>
          </div>
          <p className="text-gray-600">{order.deliveryAddress}</p>
        </div>

        {/* Items */}
        <div className="card p-4">
          <h3 className="font-bold text-gray-800 mb-3">{t('Dorilar', 'Дорилар')}</h3>
          {order.items.map((item, idx) => (
            <div key={idx} className="flex justify-between items-center py-2 border-b border-gray-100 last:border-0">
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-500">{item.quantity}x</span>
                <span className="text-sm">{item.medicine.name}</span>
              </div>
              <span className="font-medium">{(item.medicine.price * item.quantity).toLocaleString()} so'm</span>
            </div>
          ))}
          <div className="flex justify-between items-center mt-3 pt-3 border-t border-gray-200">
            <span className="font-bold">{t('Jami', 'Жами')}</span>
            <span className="font-bold text-primary-600">{order.totalAmount.toLocaleString()} so'm</span>
          </div>
        </div>
      </div>
    </div>
  );
}