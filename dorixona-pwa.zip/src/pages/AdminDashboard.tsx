import { useNavigate } from 'react-router-dom';
import { Package, Users, Pill, TrendingUp, DollarSign, ShoppingCart, ArrowRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import Header from '../components/Header';

export default function AdminDashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { t } = useLanguage();

  if (!user || user.role !== 'admin') {
    return (
      <div className="page-container flex items-center justify-center">
        <p className="text-gray-500">{t('Ruxsat yo\'q', 'Рухсат йўқ')}</p>
      </div>
    );
  }

  const stats = [
    { icon: ShoppingCart, label: t('Bugungi buyurtmalar', 'Бугунги буюртмалар'), value: '12', color: 'bg-blue-500' },
    { icon: DollarSign, label: t('Bugungi daromad', 'Бугунги даромад'), value: '1,250,000', color: 'bg-emerald-500' },
    { icon: Users, label: t('Yangi mijozlar', 'Янги мижозлар'), value: '5', color: 'bg-purple-500' },
    { icon: Package, label: t('Yetkazilgan', 'Етказилган'), value: '8', color: 'bg-amber-500' },
  ];

  const menuItems = [
    { icon: Pill, label: t('Dorilarni boshqarish', 'Дориларни бошқариш'), path: '/admin/medicines', color: 'text-blue-600 bg-blue-50' },
    { icon: ShoppingCart, label: t('Buyurtmalarni boshqarish', 'Буюртмаларни бошқариш'), path: '/admin/orders', color: 'text-emerald-600 bg-emerald-50' },
    { icon: Users, label: t('Foydalanuvchilar', 'Фойдаланувчилар'), path: '/admin/users', color: 'text-purple-600 bg-purple-50' },
    { icon: TrendingUp, label: t('Hisobotlar', 'Ҳисоботлар'), path: '/admin', color: 'text-amber-600 bg-amber-50' },
  ];

  return (
    <div className="page-container">
      <Header title={t('Admin Panel', 'Админ Панел')} showBack={false} showCart={false} />

      <div className="px-4 pt-4 space-y-4 pb-24">
        {/* Stats */}
        <div className="grid grid-cols-2 gap-3">
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <div key={idx} className="card p-4">
                <div className={`w-10 h-10 ${stat.color} rounded-xl flex items-center justify-center text-white mb-2`}>
                  <Icon size={20} />
                </div>
                <div className="text-2xl font-bold text-gray-800">{stat.value}</div>
                <div className="text-xs text-gray-500">{stat.label}</div>
              </div>
            );
          })}
        </div>

        {/* Menu */}
        <div className="space-y-2">
          {menuItems.map(item => {
            const Icon = item.icon;
            return (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className="w-full card p-4 flex items-center gap-3 active:scale-[0.98] transition-transform"
              >
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${item.color}`}>
                  <Icon size={24} />
                </div>
                <span className="flex-1 text-left font-medium text-gray-700">{item.label}</span>
                <ArrowRight size={20} className="text-gray-400" />
              </button>
            );
          })}
        </div>

        {/* Recent Activity */}
        <div className="card p-4">
          <h2 className="font-bold text-gray-800 mb-3">{t('So\'nggi faoliyat', 'Сўнгги фаолият')}</h2>
          <div className="space-y-3">
            {[
              { text: 'Yangi buyurtma #1234', time: '5 daqiqa oldin', color: 'bg-blue-500' },
              { text: 'Paracetamol zaxirasi tugayapti', time: '15 daqiqa oldin', color: 'bg-red-500' },
              { text: 'Farmatsevt Aziza onlayn', time: '30 daqiqa oldin', color: 'bg-emerald-500' },
            ].map((item, idx) => (
              <div key={idx} className="flex items-center gap-3">
                <div className={`w-2 h-2 rounded-full ${item.color}`}></div>
                <span className="text-sm text-gray-700 flex-1">{item.text}</span>
                <span className="text-xs text-gray-400">{item.time}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}