import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Package, ChevronRight, Clock, CheckCircle, Truck, XCircle } from 'lucide-react';
import { Order } from '../types';
import Header from '../components/Header';
import BottomNav from '../components/BottomNav';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';

const statusConfig = {
  pending: { label: 'Kutilmoqda', color: 'bg-amber-100 text-amber-700', icon: Clock },
  processing: { label: 'Tayyorlanmoqda', color: 'bg-blue-100 text-blue-700', icon: Package },
  ready: { label: 'Tayyor', color: 'bg-purple-100 text-purple-700', icon: CheckCircle },
  out_for_delivery: { label: 'Yo\'lda', color: 'bg-emerald-100 text-emerald-700', icon: Truck },
  delivered: { label: 'Yetkazildi', color: 'bg-green-100 text-green-700', icon: CheckCircle },
  cancelled: { label: 'Bekor qilindi', color: 'bg-red-100 text-red-700', icon: XCircle },
};

export default function Orders() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { language, t } = useLanguage();
  const [orders, setOrders] = useState<Order[]>([]);
  const [filter, setFilter] = useState<'all' | 'active' | 'completed'>('all');

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem('dorixona_orders') || '[]');
    setOrders(saved.filter((o: Order) => o.customerId === user?.id).reverse());
  }, [user]);

  const filteredOrders = orders.filter(o => {
    if (filter === 'active') return !['delivered', 'cancelled'].includes(o.status);
    if (filter === 'completed') return ['delivered', 'cancelled'].includes(o.status);
    return true;
  });

  return (
    <div className="page-container">
      <Header title={t('Buyurtmalarim', 'Буюртмаларим')} showBack />

      {/* Filter */}
      <div className="px-4 pt-4">
        <div className="flex gap-2">
          {[
            { id: 'all' as const, label: t('Barchasi', 'Барчаси') },
            { id: 'active' as const, label: t('Faol', 'Фаол') },
            { id: 'completed' as const, label: t('Yakunlangan', 'Якунланган') },
          ].map(f => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                filter === f.id ? 'bg-primary-500 text-white' : 'bg-white text-gray-600 border border-gray-200'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Orders List */}
      <div className="px-4 pt-4 space-y-3 pb-24">
        {filteredOrders.map(order => {
          const config = statusConfig[order.status];
          const StatusIcon = config.icon;
          return (
            <div 
              key={order.id}
              onClick={() => navigate(`/tracking/${order.id}`)}
              className="card p-4 active:scale-[0.98] transition-transform cursor-pointer"
            >
              <div className="flex items-center justify-between mb-3">
                <div>
                  <span className="text-xs text-gray-500">#{order.id.slice(-6)}</span>
                  <span className="text-xs text-gray-400 ml-2">
                    {new Date(order.createdAt).toLocaleDateString('uz-UZ')}
                  </span>
                </div>
                <span className={`status-badge ${config.color} flex items-center gap-1`}>
                  <StatusIcon size={12} />
                  {config.label}
                </span>
              </div>

              <div className="space-y-1 mb-3">
                {order.items.slice(0, 2).map((item, idx) => (
                  <div key={idx} className="flex justify-between text-sm">
                    <span className="text-gray-600">{item.quantity}x {item.medicine.name}</span>
                  </div>
                ))}
                {order.items.length > 2 && (
                  <span className="text-xs text-gray-400">+{order.items.length - 2} {t('ta', 'та')}</span>
                )}
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                <span className="font-bold text-primary-600">{order.totalAmount.toLocaleString()} so'm</span>
                <span className="text-sm text-gray-500 flex items-center gap-1">
                  {t('Kuzatish', 'Кузатиш')} <ChevronRight size={16} />
                </span>
              </div>
            </div>
          );
        })}

        {filteredOrders.length === 0 && (
          <div className="text-center py-12">
            <span className="text-6xl mb-4 block">📦</span>
            <p className="text-gray-500">{t('Buyurtmalar yo\'q', 'Буюртмалар йўқ')}</p>
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}