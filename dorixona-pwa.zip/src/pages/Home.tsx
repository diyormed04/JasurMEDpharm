import { useNavigate } from 'react-router-dom';
import { Search, MapPin, Phone, Pill, Heart, Shield, Sparkles, ChevronRight, Tag } from 'lucide-react';
import { medicines, promotions, categories } from '../data/medicines';
import Header from '../components/Header';
import BottomNav from '../components/BottomNav';
import MedicineCard from '../components/MedicineCard';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';

export default function Home() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { language, t } = useLanguage();

  if (!user) {
    navigate('/login');
    return null;
  }

  const featuredMedicines = medicines.slice(0, 4);
  const popularMedicines = medicines.slice(0, 6);

  return (
    <div className="page-container">
      <Header showBack={false} />

      {/* Search */}
      <div className="px-4 -mt-2 mb-4">
        <div 
          onClick={() => navigate('/catalog')}
          className="bg-white rounded-2xl shadow-md p-4 flex items-center gap-3 cursor-pointer active:scale-95 transition-transform"
        >
          <Search className="text-gray-400" size={20} />
          <span className="text-gray-400">{t('Dori qidirish...', 'Дори қидириш...')}</span>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="px-4 mb-6">
        <div className="grid grid-cols-4 gap-3">
          <button onClick={() => navigate('/prescription')} className="flex flex-col items-center gap-1">
            <div className="w-14 h-14 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600">
              <Pill size={24} />
            </div>
            <span className="text-xs text-gray-600">{t('Retsept', 'Рецепт')}</span>
          </button>
          <button onClick={() => navigate('/chat')} className="flex flex-col items-center gap-1">
            <div className="w-14 h-14 bg-emerald-100 rounded-2xl flex items-center justify-center text-emerald-600">
              <Heart size={24} />
            </div>
            <span className="text-xs text-gray-600">{t('Maslahat', 'Маслаҳат')}</span>
          </button>
          <button onClick={() => navigate('/orders')} className="flex flex-col items-center gap-1">
            <div className="w-14 h-14 bg-amber-100 rounded-2xl flex items-center justify-center text-amber-600">
              <Shield size={24} />
            </div>
            <span className="text-xs text-gray-600">{t('Buyurtma', 'Буюртма')}</span>
          </button>
          <button onClick={() => navigate('/catalog')} className="flex flex-col items-center gap-1">
            <div className="w-14 h-14 bg-purple-100 rounded-2xl flex items-center justify-center text-purple-600">
              <Sparkles size={24} />
            </div>
            <span className="text-xs text-gray-600">{t('Aksiya', 'Аксия')}</span>
          </button>
        </div>
      </div>

      {/* Promotions */}
      {promotions.filter(p => p.active).length > 0 && (
        <div className="px-4 mb-6">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-bold text-lg text-gray-800">{t('Aksiyalar', 'Аксиялар')}</h2>
            <button onClick={() => navigate('/catalog')} className="text-primary-500 text-sm flex items-center gap-1">
              {t('Barchasi', 'Барчаси')} <ChevronRight size={16} />
            </button>
          </div>
          <div className="flex gap-3 overflow-x-auto no-scrollbar snap-x snap-mandatory">
            {promotions.filter(p => p.active).map(promo => (
              <div 
                key={promo.id}
                className="min-w-[280px] snap-start card relative overflow-hidden"
              >
                <img src={promo.image} alt={promo.title} className="w-full h-32 object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-4">
                  <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-lg w-fit mb-1">
                    -{promo.discount}%
                  </span>
                  <h3 className="text-white font-bold text-sm">
                    {language === 'latin' ? promo.title : (promo.titleCyrillic || promo.title)}
                  </h3>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Categories */}
      <div className="px-4 mb-6">
        <h2 className="font-bold text-lg text-gray-800 mb-3">{t('Kategoriyalar', 'Категориялар')}</h2>
        <div className="flex gap-3 overflow-x-auto no-scrollbar">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => navigate('/catalog')}
              className="min-w-[100px] bg-white rounded-xl p-3 shadow-sm border border-gray-100 flex flex-col items-center gap-2 active:scale-95 transition-transform"
            >
              <span className="text-2xl">
                {cat.id === 'painkillers' && '💊'}
                {cat.id === 'vitamins' && '💚'}
                {cat.id === 'antibiotics' && '🛡️'}
                {cat.id === 'cosmetics' && '✨'}
                {cat.id === 'all' && '📋'}
              </span>
              <span className="text-xs font-medium text-gray-700">
                {language === 'latin' ? cat.name : cat.nameCyrillic}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Featured */}
      <div className="px-4 mb-6">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-bold text-lg text-gray-800">{t('Mashhur dorilar', 'Машҳур дорилар')}</h2>
          <button onClick={() => navigate('/catalog')} className="text-primary-500 text-sm flex items-center gap-1">
            {t('Barchasi', 'Барчаси')} <ChevronRight size={16} />
          </button>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {featuredMedicines.map(med => (
            <MedicineCard key={med.id} medicine={med} />
          ))}
        </div>
      </div>

      {/* Popular */}
      <div className="px-4 mb-6">
        <h2 className="font-bold text-lg text-gray-800 mb-3">{t('Siz uchun', 'Сиз учун')}</h2>
        <div className="space-y-3">
          {popularMedicines.map(med => (
            <div 
              key={med.id}
              onClick={() => navigate(`/medicine/${med.id}`)}
              className="card flex gap-3 p-3 active:scale-[0.98] transition-transform cursor-pointer"
            >
              <img src={med.image} alt={med.name} className="w-20 h-20 object-cover rounded-xl" />
              <div className="flex-1">
                <h3 className="font-semibold text-sm text-gray-800">
                  {language === 'latin' ? med.name : (med.nameCyrillic || med.name)}
                </h3>
                <p className="text-xs text-gray-500 mt-0.5">{med.manufacturer}</p>
                <div className="flex items-center justify-between mt-2">
                  <span className="font-bold text-primary-600">{med.price.toLocaleString()} so'm</span>
                  {med.prescription && (
                    <span className="text-[10px] bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full">
                      {t('Retsept', 'Рецепт')}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Pharmacy Info */}
      <div className="px-4 mb-24">
        <div className="card p-4 bg-gradient-to-r from-primary-500 to-primary-600 text-white">
          <h3 className="font-bold mb-2">{t('Bizning dorixonamiz', 'Бизнинг дорихонамиз')}</h3>
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2">
              <MapPin size={16} />
              <span>Toshkent, Chilonzor tumani</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone size={16} />
              <span>+998 71 123 45 67</span>
            </div>
            <div className="flex items-center gap-2">
              <Tag size={16} />
              <span>{t('24/7 onlayn xizmat', '24/7 онлайн хизмат')}</span>
            </div>
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}