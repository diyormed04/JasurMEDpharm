import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapPin, Clock, CreditCard, Banknote, QrCode, Check, Truck } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import Header from '../components/Header';
import { useLanguage } from '../context/LanguageContext';

export default function Checkout() {
  const navigate = useNavigate();
  const { items, totalPrice, clearCart } = useCart();
  const { user } = useAuth();
  const { t } = useLanguage();

  const [address, setAddress] = useState(user?.address || '');
  const [deliveryTime, setDeliveryTime] = useState<'express' | 'standard'>('standard');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'qr'>('cash');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const deliveryFee = deliveryTime === 'express' ? 15000 : 5000;
  const total = totalPrice + deliveryFee;

  const handleSubmit = async () => {
    if (!address.trim()) return;
    setIsSubmitting(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Save order to localStorage
    const orders = JSON.parse(localStorage.getItem('dorixona_orders') || '[]');
    const newOrder = {
      id: 'ORD' + Date.now(),
      customerId: user?.id,
      customerName: user?.name,
      customerPhone: user?.phone,
      items,
      totalAmount: total,
      status: 'pending',
      paymentMethod,
      paymentStatus: 'pending',
      deliveryAddress: address,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      notes
    };
    orders.push(newOrder);
    localStorage.setItem('dorixona_orders', JSON.stringify(orders));

    clearCart();
    setIsSubmitting(false);
    navigate('/orders');
  };

  return (
    <div className="page-container">
      <Header title={t('Buyurtma berish', 'Буюртма бериш')} showBack />

      <div className="px-4 pt-4 space-y-4 pb-32">
        {/* Items */}
        <div className="card p-4">
          <h2 className="font-bold text-gray-800 mb-3">{t('Dorilar', 'Дорилар')}</h2>
          {items.map(item => (
            <div key={item.medicine.id} className="flex justify-between items-center py-2 border-b border-gray-100 last:border-0">
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-500">{item.quantity}x</span>
                <span className="text-sm">{item.medicine.name}</span>
              </div>
              <span className="font-medium">{(item.medicine.price * item.quantity).toLocaleString()} so'm</span>
            </div>
          ))}
          <div className="flex justify-between items-center mt-3 pt-3 border-t border-gray-200">
            <span className="font-bold">{t('Jami', 'Жами')}</span>
            <span className="font-bold text-primary-600">{totalPrice.toLocaleString()} so'm</span>
          </div>
        </div>

        {/* Address */}
        <div className="card p-4">
          <div className="flex items-center gap-2 mb-3">
            <MapPin size={20} className="text-primary-500" />
            <h2 className="font-bold text-gray-800">{t('Yetkazish manzili', 'Етказиш манзили')}</h2>
          </div>
          <textarea
            value={address}
            onChange={e => setAddress(e.target.value)}
            placeholder={t('Tuman, ko\'cha, uy, xonadon...', 'Туман, кўча, уй, хонадон...')}
            className="input-field resize-none h-20"
            required
          />
        </div>

        {/* Delivery Time */}
        <div className="card p-4">
          <div className="flex items-center gap-2 mb-3">
            <Clock size={20} className="text-primary-500" />
            <h2 className="font-bold text-gray-800">{t('Yetkazish vaqti', 'Етказиш вақти')}</h2>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => setDeliveryTime('standard')}
              className={`p-3 rounded-xl border-2 text-left transition-colors ${
                deliveryTime === 'standard' 
                  ? 'border-primary-500 bg-primary-50' 
                  : 'border-gray-200'
              }`}
            >
              <Truck size={20} className="mb-1" />
              <div className="font-semibold text-sm">{t('Standart', 'Стандарт')}</div>
              <div className="text-xs text-gray-500">{t('2-4 soat', '2-4 соат')}</div>
              <div className="text-sm font-bold mt-1">5,000 so'm</div>
            </button>
            <button
              onClick={() => setDeliveryTime('express')}
              className={`p-3 rounded-xl border-2 text-left transition-colors ${
                deliveryTime === 'express' 
                  ? 'border-primary-500 bg-primary-50' 
                  : 'border-gray-200'
              }`}
            >
              <Truck size={20} className="mb-1 text-amber-500" />
              <div className="font-semibold text-sm">{t('Tezkor', 'Тезкор')}</div>
              <div className="text-xs text-gray-500">{t('1 soat', '1 соат')}</div>
              <div className="text-sm font-bold mt-1">15,000 so'm</div>
            </button>
          </div>
        </div>

        {/* Payment Method */}
        <div className="card p-4">
          <div className="flex items-center gap-2 mb-3">
            <CreditCard size={20} className="text-primary-500" />
            <h2 className="font-bold text-gray-800">{t('To\'lov usuli', 'Тўлов усули')}</h2>
          </div>
          <div className="space-y-2">
            <button
              onClick={() => setPaymentMethod('cash')}
              className={`w-full p-3 rounded-xl border-2 flex items-center gap-3 transition-colors ${
                paymentMethod === 'cash' 
                  ? 'border-primary-500 bg-primary-50' 
                  : 'border-gray-200'
              }`}
            >
              <Banknote size={24} className="text-emerald-500" />
              <div className="text-left">
                <div className="font-semibold">{t('Naqd pul', 'Нақд пул')}</div>
                <div className="text-xs text-gray-500">{t('Yetkazilganda to\'lash', 'Етказилганда тўлаш')}</div>
              </div>
              {paymentMethod === 'cash' && <Check size={20} className="ml-auto text-primary-500" />}
            </button>
            <button
              onClick={() => setPaymentMethod('qr')}
              className={`w-full p-3 rounded-xl border-2 flex items-center gap-3 transition-colors ${
                paymentMethod === 'qr' 
                  ? 'border-primary-500 bg-primary-50' 
                  : 'border-gray-200'
              }`}
            >
              <QrCode size={24} className="text-blue-500" />
              <div className="text-left">
                <div className="font-semibold">{t('QR-kod', 'QR-код')}</div>
                <div className="text-xs text-gray-500">{t('Click/Payme/Uzum orqali', 'Click/Payme/Uzum орқали')}</div>
              </div>
              {paymentMethod === 'qr' && <Check size={20} className="ml-auto text-primary-500" />}
            </button>
          </div>
        </div>

        {/* Notes */}
        <div className="card p-4">
          <h2 className="font-bold text-gray-800 mb-2">{t('Qo\'shimcha izoh', 'Қўшимча изоҳ')}</h2>
          <textarea
            value={notes}
            onChange={e => setNotes(e.target.value)}
            placeholder={t('Masalan: 2-qavat, eshik qo\'ng\'irog\'i...', 'Масалан: 2-қават, эшик қўнғироғи...')}
            className="input-field resize-none h-16"
          />
        </div>
      </div>

      {/* Total & Submit */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 safe-bottom z-50">
        <div className="max-w-lg mx-auto">
          <div className="flex justify-between items-center mb-1">
            <span className="text-gray-600">{t('Dorilar', 'Дорилар')}:</span>
            <span>{totalPrice.toLocaleString()} so'm</span>
          </div>
          <div className="flex justify-between items-center mb-1">
            <span className="text-gray-600">{t('Yetkazish', 'Етказиш')}:</span>
            <span>{deliveryFee.toLocaleString()} so'm</span>
          </div>
          <div className="flex justify-between items-center mb-3 pt-2 border-t border-gray-200">
            <span className="font-bold text-lg">{t('Umumiy', 'Умумий')}:</span>
            <span className="font-bold text-2xl text-primary-600">{total.toLocaleString()} so'm</span>
          </div>
          <button 
            onClick={handleSubmit}
            disabled={!address.trim() || isSubmitting}
            className="btn-primary w-full disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <span className="animate-spin">⏳</span>
            ) : (
              <>
                <Check size={20} />
                <span>{t('Buyurtma berish', 'Буюртма бериш')}</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}