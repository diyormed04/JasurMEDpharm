import { useNavigate } from 'react-router-dom';
import { MapPin, Navigation, Phone, Package } from 'lucide-react';
import Header from '../components/Header';
import { useLanguage } from '../context/LanguageContext';

export default function MapPage() {
  const navigate = useNavigate();
  const { t } = useLanguage();

  const deliveries = [
    { id: 1, address: 'Chilonzor 8-kv, 12-uy', customer: 'Alisher Rahimov', phone: '+998901234569', status: 'pending' },
    { id: 2, address: 'Yunusobod 5-kv, 45-uy', customer: 'Gulnora Karimova', phone: '+998901234571', status: 'delivering' },
  ];

  return (
    <div className="page-container">
      <Header title={t('Xarita', 'Харита')} showBack />

      {/* Map Placeholder */}
      <div className="h-64 bg-gradient-to-br from-emerald-100 to-blue-100 flex items-center justify-center relative">
        <div className="text-center">
          <span className="text-6xl">🗺️</span>
          <p className="text-gray-600 mt-2">{t('Xarita joylashuvi', 'Харита жойлашуви')}</p>
          <p className="text-xs text-gray-500">Google Maps API ulanadi</p>
        </div>

        {/* Map Pins */}
        <div className="absolute top-1/4 left-1/4">
          <div className="w-8 h-8 bg-primary-500 rounded-full flex items-center justify-center text-white text-xs font-bold animate-bounce">1</div>
        </div>
        <div className="absolute top-1/2 right-1/3">
          <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-bold animate-bounce" style={{animationDelay: '0.5s'}}>2</div>
        </div>
      </div>

      {/* Delivery List */}
      <div className="px-4 pt-4 space-y-3 pb-24">
        <h2 className="font-bold text-gray-800">{t('Yetkazish manzillari', 'Етказиш манзиллари')}</h2>

        {deliveries.map(delivery => (
          <div key={delivery.id} className="card p-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center text-primary-600 font-bold">
                {delivery.id}
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-gray-800">{delivery.address}</h3>
                <p className="text-sm text-gray-500">{delivery.customer}</p>
                <div className="flex items-center gap-2 mt-2">
                  <button className="flex items-center gap-1 px-3 py-1 bg-primary-500 text-white text-sm rounded-lg">
                    <Navigation size={14} /> {t('Yo\'nalish', 'Йўналиш')}
                  </button>
                  <button className="flex items-center gap-1 px-3 py-1 bg-emerald-500 text-white text-sm rounded-lg">
                    <Phone size={14} /> {t('Qo\'ng\'iroq', 'Қўнғироқ')}
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}