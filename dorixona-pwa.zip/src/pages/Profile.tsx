import { useNavigate } from 'react-router-dom';
import { User, Phone, MapPin, Package, MessageSquare, FileText, Heart, Settings, LogOut, ChevronRight, Globe } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import Header from '../components/Header';
import BottomNav from '../components/BottomNav';

export default function Profile() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const { language, toggleLanguage, t } = useLanguage();

  const menuItems = [
    { icon: Package, label: t('Buyurtmalarim', 'Буюртмаларим'), path: '/orders', color: 'text-blue-500 bg-blue-50' },
    { icon: FileText, label: t('Retseptlarim', 'Рецептларим'), path: '/prescription', color: 'text-amber-500 bg-amber-50' },
    { icon: MessageSquare, label: t('Maslahatlar', 'Маслаҳатлар'), path: '/chat', color: 'text-emerald-500 bg-emerald-50' },
    { icon: Heart, label: t('Sevimlilar', 'Севимлилар'), path: '/catalog', color: 'text-red-500 bg-red-50' },
  ];

  return (
    <div className="page-container">
      <Header title={t('Profil', 'Профил')} showBack={false} showCart={false} />

      {/* User Info */}
      <div className="px-4 -mt-2">
        <div className="card p-4 flex items-center gap-4">
          <div className="w-16 h-16 bg-primary-100 rounded-2xl flex items-center justify-center text-3xl">
            {user?.role === 'customer' && '👤'}
            {user?.role === 'pharmacist' && '👩‍⚕️'}
            {user?.role === 'courier' && '🚚'}
            {user?.role === 'admin' && '👨‍💼'}
          </div>
          <div className="flex-1">
            <h2 className="font-bold text-lg text-gray-800">{user?.name}</h2>
            <p className="text-sm text-gray-500">{user?.phone}</p>
            <span className="inline-block mt-1 px-2 py-0.5 bg-primary-100 text-primary-700 text-xs rounded-full font-medium capitalize">
              {user?.role}
            </span>
          </div>
        </div>
      </div>

      {/* Menu */}
      <div className="px-4 pt-4 space-y-2 pb-24">
        {menuItems.map(item => {
          const Icon = item.icon;
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className="w-full card p-4 flex items-center gap-3 active:scale-[0.98] transition-transform"
            >
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${item.color}`}>
                <Icon size={20} />
              </div>
              <span className="flex-1 text-left font-medium text-gray-700">{item.label}</span>
              <ChevronRight size={20} className="text-gray-400" />
            </button>
          );
        })}

        {/* Language Toggle */}
        <button
          onClick={toggleLanguage}
          className="w-full card p-4 flex items-center gap-3 active:scale-[0.98] transition-transform"
        >
          <div className="w-10 h-10 rounded-xl flex items-center justify-center text-purple-500 bg-purple-50">
            <Globe size={20} />
          </div>
          <span className="flex-1 text-left font-medium text-gray-700">{t('Til', 'Тил')}</span>
          <span className="text-sm text-gray-500">{language === 'latin' ? 'O\'zbek (Lotin)' : 'Ўзбек (Кирилл)'}</span>
          <ChevronRight size={20} className="text-gray-400" />
        </button>

        {/* Logout */}
        <button
          onClick={() => {
            logout();
            navigate('/login');
          }}
          className="w-full card p-4 flex items-center gap-3 active:scale-[0.98] transition-transform mt-4"
        >
          <div className="w-10 h-10 rounded-xl flex items-center justify-center text-red-500 bg-red-50">
            <LogOut size={20} />
          </div>
          <span className="flex-1 text-left font-medium text-red-500">{t('Chiqish', 'Чиқиш')}</span>
        </button>
      </div>

      <BottomNav />
    </div>
  );
}