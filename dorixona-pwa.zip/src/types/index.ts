export type UserRole = 'admin' | 'pharmacist' | 'customer' | 'courier';

export interface User {
  id: string;
  phone: string;
  name: string;
  role: UserRole;
  avatar?: string;
  email?: string;
  address?: string;
  createdAt: string;
}

export interface Medicine {
  id: string;
  name: string;
  nameCyrillic?: string;
  description: string;
  descriptionCyrillic?: string;
  price: number;
  oldPrice?: number;
  stock: number;
  category: string;
  image: string;
  manufacturer: string;
  dosage?: string;
  symptoms?: string[];
  rating: number;
  reviews: number;
  prescription: boolean;
}

export interface CartItem {
  medicine: Medicine;
  quantity: number;
}

export type OrderStatus = 'pending' | 'processing' | 'ready' | 'out_for_delivery' | 'delivered' | 'cancelled';
export type PaymentMethod = 'cash' | 'qr';

export interface Order {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  items: CartItem[];
  totalAmount: number;
  status: OrderStatus;
  paymentMethod: PaymentMethod;
  paymentStatus: 'pending' | 'paid';
  deliveryAddress: string;
  courierId?: string;
  courierName?: string;
  createdAt: string;
  updatedAt: string;
  notes?: string;
}

export interface Prescription {
  id: string;
  customerId: string;
  customerName: string;
  image: string;
  status: 'pending' | 'approved' | 'rejected';
  pharmacistId?: string;
  pharmacistName?: string;
  rejectionReason?: string;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: UserRole;
  text: string;
  timestamp: string;
}

export interface Consultation {
  id: string;
  customerId: string;
  customerName: string;
  pharmacistId?: string;
  pharmacistName?: string;
  status: 'waiting' | 'active' | 'completed';
  messages: ChatMessage[];
  createdAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  read: boolean;
  type: 'order' | 'prescription' | 'promotion' | 'chat';
  createdAt: string;
}

export interface Promotion {
  id: string;
  title: string;
  titleCyrillic?: string;
  description: string;
  discount: number;
  image: string;
  startDate: string;
  endDate: string;
  active: boolean;
}

export type Language = 'latin' | 'cyrillic';
